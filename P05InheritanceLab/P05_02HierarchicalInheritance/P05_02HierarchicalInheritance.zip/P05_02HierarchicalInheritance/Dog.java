/**
 * Created by IntelliJ IDEA
 * User: Stilyan Petrov
 * Date: 17.4.2023 г.
 * Time: 20:07
 */
package P05_02HierarchicalInheritance;

public class Dog extends Animal{
    public void bark() {
        System.out.println("barking...");
    }
}
