/**
 * Created by IntelliJ IDEA
 * User: Stilyan Petrov
 * Date: 17.4.2023 г.
 * Time: 20:15
 */
package P05_03RandomArrayList;

public class Main {
    public static void main(String[] args) {
        
    }
}
