package telephony;

/**
 * Created by IntelliJ IDEA
 * User: Stilyan Petrov
 * Date: 21.4.2023 г.
 * Time: 18:23
 */
public interface Callable {
    String call();
}
