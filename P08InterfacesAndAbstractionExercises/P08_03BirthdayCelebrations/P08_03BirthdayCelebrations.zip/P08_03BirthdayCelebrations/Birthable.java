package P08_03BirthdayCelebrations;

/**
 * Created by IntelliJ IDEA
 * User: Stilyan Petrov
 * Date: 20.4.2023 г.
 * Time: 19:49
 */
public interface Birthable {
    String getBirthDate();
}
