package P08_07CollectionHierarchy;

/**
 * Created by IntelliJ IDEA
 * User: Stilyan Petrov
 * Date: 23.4.2023 г.
 * Time: 7:23
 */
public interface Addable {
    int add(String toAdd);
}
