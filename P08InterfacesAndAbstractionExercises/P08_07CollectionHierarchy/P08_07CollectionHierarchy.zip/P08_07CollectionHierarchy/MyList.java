package P08_07CollectionHierarchy;

/**
 * Created by IntelliJ IDEA
 * User: Stilyan Petrov
 * Date: 23.4.2023 г.
 * Time: 7:24
 */
public interface MyList extends AddRemovable{
    int getUsed();
}
