package P08_06MilitaryElite;

/**
 * Created by IntelliJ IDEA
 * User: Stilyan Petrov
 * Date: 23.4.2023 г.
 * Time: 6:29
 */
// Разликата тук е че ми липсва цялата имплементация на този интерфейс
public interface Repair {
    String getPartName();

    int getHours();
}
