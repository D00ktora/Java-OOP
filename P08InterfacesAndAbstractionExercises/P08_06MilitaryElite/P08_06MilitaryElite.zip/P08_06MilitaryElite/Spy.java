package P08_06MilitaryElite;

/**
 * Created by IntelliJ IDEA
 * User: Stilyan Petrov
 * Date: 21.4.2023 г.
 * Time: 20:10
 */
public interface Spy {
    //първа разлика при мен е String при другите е int
    int getCodeNumber();
}
