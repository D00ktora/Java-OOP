package P08_06MilitaryElite;

/**
 * Created by IntelliJ IDEA
 * User: Stilyan Petrov
 * Date: 21.4.2023 г.
 * Time: 19:54
 */
public enum State {
    inProgress,
    finished;
}
