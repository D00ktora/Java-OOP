package P08_06MilitaryElite;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA
 * User: Stilyan Petrov
 * Date: 21.4.2023 г.
 * Time: 20:09
 */
public interface Commando {
    Collection<MissionImp> getMissions();
}
