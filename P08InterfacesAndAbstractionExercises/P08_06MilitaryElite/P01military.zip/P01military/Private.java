package P01military;

public interface Private extends Soldier {
    double getSalary();
}
