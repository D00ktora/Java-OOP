package P01military;

public interface Repair {
    String getPartName();

    int getHours();
}
