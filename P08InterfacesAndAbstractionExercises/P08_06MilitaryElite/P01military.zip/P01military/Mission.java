package P01military;

public interface Mission {
    String getCodeName();
    String getState();
    void completeMission();
}
