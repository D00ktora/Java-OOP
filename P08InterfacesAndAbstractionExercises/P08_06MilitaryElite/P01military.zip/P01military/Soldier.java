package P01military;

public interface Soldier {
    int getId();

    String getFirstName();

    String getLastName();
}
