package P01military;

public interface Spy {
    int getCodeNumber();
}
