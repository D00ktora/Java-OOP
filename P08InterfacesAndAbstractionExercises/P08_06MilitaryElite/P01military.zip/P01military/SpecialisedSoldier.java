package P01military;

public interface SpecialisedSoldier extends Soldier {
    String getCorps();
}
