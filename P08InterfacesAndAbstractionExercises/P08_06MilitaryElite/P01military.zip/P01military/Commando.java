package P01military;

import java.util.Collection;

public interface Commando {
    Collection<Mission> getMissions();
}
