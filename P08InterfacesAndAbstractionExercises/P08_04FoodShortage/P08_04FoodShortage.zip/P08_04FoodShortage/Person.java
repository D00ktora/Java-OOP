package P08_04FoodShortage;

/**
 * Created by IntelliJ IDEA
 * User: Stilyan Petrov
 * Date: 20.4.2023 г.
 * Time: 19:41
 */
public interface Person{
    String getName();
    int getAge();
}
