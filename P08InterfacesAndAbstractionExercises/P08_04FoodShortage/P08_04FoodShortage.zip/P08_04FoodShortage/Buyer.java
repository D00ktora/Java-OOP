package P08_04FoodShortage;

/**
 * Created by IntelliJ IDEA
 * User: Stilyan Petrov
 * Date: 20.4.2023 г.
 * Time: 20:50
 */
public interface Buyer {
    void buyFood();
    int getFood();
}
