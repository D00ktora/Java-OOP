/**
 * Created by IntelliJ IDEA
 * User: Stilyan Petrov
 * Date: 18.4.2023 г.
 * Time: 6:06
 */
package P06_01Person;

public class Child extends Person{
    public Child(String name, int age) {
        super(name, age);
    }
}
