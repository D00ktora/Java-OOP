/**
 * Created by IntelliJ IDEA
 * User: Stilyan Petrov
 * Date: 18.4.2023 г.
 * Time: 6:15
 */
package hero;

public class Knight extends Hero{
    public Knight(String userName, int level) {
        super(userName, level);
    }
}
