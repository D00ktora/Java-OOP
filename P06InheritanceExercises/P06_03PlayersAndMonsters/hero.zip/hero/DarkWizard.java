/**
 * Created by IntelliJ IDEA
 * User: Stilyan Petrov
 * Date: 18.4.2023 г.
 * Time: 6:15
 */
package hero;

public class DarkWizard extends Wizard{
    public DarkWizard(String userName, int level) {
        super(userName, level);
    }
}
//P06_03PlayersAndMonsters