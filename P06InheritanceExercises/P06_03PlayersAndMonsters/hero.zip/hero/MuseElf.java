/**
 * Created by IntelliJ IDEA
 * User: Stilyan Petrov
 * Date: 18.4.2023 г.
 * Time: 6:14
 */
package hero;

public class MuseElf extends Elf{
    public MuseElf(String userName, int level) {
        super(userName, level);
    }
}
