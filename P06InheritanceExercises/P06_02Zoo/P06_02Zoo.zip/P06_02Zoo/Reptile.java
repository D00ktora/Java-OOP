/**
 * Created by IntelliJ IDEA
 * User: Stilyan Petrov
 * Date: 18.4.2023 г.
 * Time: 6:09
 */
package P06_02Zoo;

public class Reptile extends Animal{
    public Reptile(String name) {
        super(name);
    }
}
