/**
 * Created by IntelliJ IDEA
 * User: Stilyan Petrov
 * Date: 18.4.2023 г.
 * Time: 6:10
 */
package P06_02Zoo;

public class Snake extends Reptile{
    public Snake(String name) {
        super(name);
    }
}
