/**
 * Created by IntelliJ IDEA
 * User: Stilyan Petrov
 * Date: 18.4.2023 г.
 * Time: 6:10
 */
package P06_02Zoo;

public class Mammal extends Animal{
    public Mammal(String name) {
        super(name);
    }
}
