/**
 * Created by IntelliJ IDEA
 * User: Stilyan Petrov
 * Date: 23.4.2023 г.
 * Time: 8:19
 */
package P09_03Animals;

public class Main {
    public static void main(String[] args) {

    }
}
