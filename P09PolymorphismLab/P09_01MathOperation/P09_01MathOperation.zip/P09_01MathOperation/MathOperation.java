/**
 * Created by IntelliJ IDEA
 * User: Stilyan Petrov
 * Date: 23.4.2023 г.
 * Time: 7:55
 */
package P09_01MathOperation;

public class MathOperation {
    public int add(int one, int two) {
        return one + two;
    }
    public int add(int one, int two, int three) {
        return one + two + three;
    }
    public int add(int one, int two, int three, int four) {
        return  one + two + three + four;
    }
}
