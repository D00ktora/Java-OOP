/**
 * Created by IntelliJ IDEA
 * User: Stilyan Petrov
 * Date: 23.4.2023 г.
 * Time: 8:27
 */
package P09_04WildFarm;

public class Vegetable extends Food{
    public Vegetable(Integer quantity) {
        super(quantity);
    }

}
