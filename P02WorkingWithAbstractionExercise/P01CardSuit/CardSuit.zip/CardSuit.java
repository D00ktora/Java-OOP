package P01CardSuit;

/**
 * Created by IntelliJ IDEA
 * User: Stilyan Petrov
 * Date: 15.4.2023 г.
 * Time: 7:02
 */
public enum CardSuit {
    CLUBS,
    DIAMONDS,
    HEARTS,
    SPADES;
}
