package P04TrafficLights;

/**
 * Created by IntelliJ IDEA
 * User: Stilyan Petrov
 * Date: 15.4.2023 г.
 * Time: 7:43
 */
public enum Lights {
    RED,
    GREEN,
    YELLOW;
}
