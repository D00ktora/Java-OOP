/**
 * Created by IntelliJ IDEA
 * User: Stilyan Petrov
 * Date: 18.4.2023 г.
 * Time: 7:30
 */
package P07_02CarShopExtended;

public interface Car {

    int TYRES = 4;

    String getModel();

    String getColor();

    int getHorsePower();
}
