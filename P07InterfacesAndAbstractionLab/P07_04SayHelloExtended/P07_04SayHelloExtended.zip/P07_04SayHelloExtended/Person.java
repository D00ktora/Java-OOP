package P07_04SayHelloExtended;

/**
 * Created by IntelliJ IDEA
 * User: Stilyan Petrov
 * Date: 20.4.2023 г.
 * Time: 18:15
 */
public interface Person {
    String getName();
    String sayHello();

}
